package com.health.constant;

public enum ProgramSellStatus {
	SELL, SOLD_OUT
}
