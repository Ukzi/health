package com.health.constant;

public enum ExercisePurpose {
	DIET, HEALTHY, MUSCLE
}
