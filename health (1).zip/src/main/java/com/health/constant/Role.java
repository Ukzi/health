package com.health.constant;

public enum Role {
	USER, ADMIN
}
