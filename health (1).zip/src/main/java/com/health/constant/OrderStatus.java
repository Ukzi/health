package com.health.constant;

public enum OrderStatus {
	ORDER, CANCEL
}
