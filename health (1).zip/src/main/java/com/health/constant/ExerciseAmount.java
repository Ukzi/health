package com.health.constant;

public enum ExerciseAmount {
	LESS, NORMAL, MUCH
}
